// Importing  UIKit and Foundation
import UIKit
import Foundation

struct Genre: Codable {
    let id: Int
    let name: String
}

struct Movie: Codable {
    // Assigning types to variables
    let title: String
    let overview: String
    let movieLanguage: String
    let voteAverage: Float
    let genres: [Genre]
    
    
    enum CodingKeys: String, CodingKey {
        case title = "title"
        case overview = "overview"
        case voteAverage = "vote_average"
        case movieLanguage = "original_language"
        case genres = "genres"
    }
    
    // Preparing testDescription to check if information is gathered
    var testDescription: String {
        return "\nTitle: \(title)\nLanguage: \(movieLanguage)\nOverview: \(overview)\nRating: \(voteAverage)\nGenres:\(genres.compactMap({$0.name}))"
    }
}

struct API {
    // Assigning string value to
    static let endpoint = "https://api.themoviedb.org/3"
    static let movieEndpoint = "/movie/"
    
    // Temporary movieId to test API
    static let movieId = "299536"
    
    static let searchEndpoint = "/search/"
    static let apiKey = "?api_key=a5442a268940dbed5319a66ad02a3abf"
    
    // Assembling API URL
    static let endpointURL = URL(string: endpoint + movieEndpoint + movieId + apiKey)!

    // Getting Data from the API
    static func getMovie(completion: @escaping ((Movie) -> Void)) {
        let session = URLSession(configuration: URLSessionConfiguration.default)
 
        let request = URLRequest(url: endpointURL)
        print(request)
        session.dataTask(with: request) { data, _, _ in
            guard let data = data else { return }
            guard let movie = try? JSONDecoder().decode(Movie.self, from: data) else { return }
            return completion(movie)
        }.resume()
    }
}

// Printing movie description
API.getMovie { movie in
    print(movie.testDescription)
}
