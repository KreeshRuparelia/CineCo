// Importing  UIKit and Foundation
import UIKit
import Foundation

struct Genre: Codable {
    let id: Int
    let name: String
}

struct Movie: Codable {
    // Assigning types to variables
    let title: String
    let overview: String
    let movieLanguage: String
    let voteAverage: Float
    let genres: [Genre]

    
    enum CodingKeys: String, CodingKey {
        case title = "title"
        case overview = "overview"
        case voteAverage = "vote_average"
        case movieLanguage = "original_language"
        case genres = "genres"
    }
    
    // Preparing testDescription to check if information is gathered
    
    var testDescription: String {
        return "\nTitle: \(title)\nLanguage: \(movieLanguage)\nOverview: \(overview)\nRating: \(voteAverage)\nGenres:\(genres.compactMap({$0.name}))"
    }
}


struct MovieListResult: Codable {
    let page: Int
    let totalPages: Int
    let totalResults: Int
    let results: [MovieListItem]

    enum CodingKeys: String, CodingKey {
        case totalPages = "total_pages"
        case totalResults = "total_results"
        case page = "page"
        case results = "results"
    }
}

struct MovieListItem: Codable {
    let movieId: Int
    let title: String
    let overview: String
    let movieLanguage: String
    let voteAverage: Float
    
    enum CodingKeys: String, CodingKey {
        case movieId = "id"
        case title = "title"
        case overview = "overview"
        case voteAverage = "vote_average"
        case movieLanguage = "original_language"
    }
}
//
//struct MovieByGenre: Codable {
//    // Assigning types to variables
//    let page: Int
//    let results: [Results]
//    let totalPages: Int
//    let totalResults: Int
//
//    var testDescription: String {
//        return "\nTitle: \(title)\nLanguage: \(movieLanguage)\nOverview: \(overview)\nRating: \(voteAverage)"
//    }
//}

struct API {
    // Assigning string value to
    static let endpoint = "https://api.themoviedb.org/3"
    static let movieEndpoint = "/movie/"
    
    // Temporary movieId to test API
    static let movieId = "299536"
    
    static let searchEndpoint = "/search/"
    static let apiKey = "?api_key=a5442a268940dbed5319a66ad02a3abf"
    
    // Assembling API URL
    static let endpointURL = URL(string: "https://api.themoviedb.org/3/discover/movie?api_key=a5442a268940dbed5319a66ad02a3abf&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=1&with_genres=35&with_watch_monetization_types=flatrate")!

    // Getting Data from the API
    static func getMovie(completion: @escaping ((MovieListResult) -> Void)) {
        let session = URLSession(configuration: URLSessionConfiguration.default)
        let request = URLRequest(url: endpointURL)
        print(request)
        session.dataTask(with: request) { data, _, _ in
            guard let data = data else { return }
            print("here")
            // let json = NSString(data: data, encoding: String.Encoding.utf8.rawValue)
            // print(data.count)
            guard let result = try? JSONDecoder().decode(MovieListResult.self, from: data) else { return }
            return completion(result)
        }.resume()
    }
}

// Printing movie description
API.getMovie { result in
    print(result)
}
